smith-chart
===========

Simple Smith chart application serving as a paper.js demo

Use it at http://cemulate.github.io/smith-chart
